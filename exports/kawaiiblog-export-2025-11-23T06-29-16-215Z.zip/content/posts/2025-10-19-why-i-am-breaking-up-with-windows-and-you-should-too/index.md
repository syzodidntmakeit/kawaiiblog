---
title: Why I am breaking up with Windows (and you should too)
date: "2025-10-19"
category: tech
excerpt: >-
  Windows is being very invasive in their actions, choosing to be an AI agent
  first operating system, and macOS is a sin against humainty. But there is an
  alternative...
  - windows
  - linux
  - os
---

## Introduction

Look, just use Linux. You don't even need terminal. It's not big scary any more.

## Microsoft: The Partner Who Won't Stop Tracking You

Microsoft; purveyors of intrusive bloated. Popular for it's Windows Operating System. Proprietary, intrusive and extremely babys the user.

> "You wanna dewete a fiwe? hmm? yesh u do. mhm. hewre. lemme do it for you. use the GUI."

And it tracks users' data so much it makes the Chine Communist Party get an erection. They know so much about you, they could probably predict that your 16 daughter is going through pregnancy before you do. (You should probably talk to her about it btw).

All this data collection, can I opt out? Nah. Nope. Your data belongs to Microsoft now. They make money from this by selling it to advertisers, or worse, the Russians. Sure, you can go through the Group Policy Editor. But I'd rather defuse a fucking bomb.

## Windows 10 is dead

We never liked it. But it's the only thing good about the 4 blue square company. It's so widely adopted, we have no option BUT to use Windows 10. What application do you know that doesn't support Windows? (Mac OS is dead to me). And Windows 10 is now declared End Of Life by the company Indians use to scam old white Americans. Any good memories you had from Windows X, pales in comparison to the dumpster fire that it was during launch. And God forbid user use Windows 7.

Ok… So why not just update? Surely this multi-trillion dollar company listened to their customer base and fixed any underlying issues within it's proprietary Operating System, right?

## Windows 11: The Devil's Necromancer

Whatever perfect that is Windows 10 (what little there was), ceases to exist in their latest, newest and forced-down-our-throat Operating Shitpiece; Windows 11.

Microsoft, fuck you. Where do I begin? Even more bloatware, even more updates, bitlocker that locks down on booting another OS, and worse of all, patching up any way to make a local account. I have a laptop that ran Windows 11 before Windows 10 died. And I made it with a local account by bypassing the Out-Of-Box-Experience when installing the OS. Now I'm too afraid to update my laptop because it might kick me out and force me to make a Microsoft account.

You might be thinking, "Microsoft wants you to make an account to use Windows 11 so they can make devices using their OS have the most up to date security!" And you are absolutely right. But let me introduce you to the idea of ulterior motive. Sure, they wanna update security so if there is a malware that is hidden within a Microsoft accepted driver like what happened with Genshin Impact. But this means that they can track you as easily as pissing off white people on Twitter (not X, fuck you). Why do I need to be signed in on MY DEVICE, my LOCAL device? I just wanna watch funny cats on YouTube or girls in revealing clothing dancing on TikTok.

"Ok, Isaiah. I actually like being tracked by big bad." You're fucking weird. But also, you still can't. Check your hardware. And I don't mean CPU cores, RAM capacity or storage. I mean TPM 2.0 and secure boot. The requirements for Windows 11 makes American police officers in the second state look like Ghandi. What regular user would EVER need Secure Boot, other than to stop them from installing another OS. EVEN IF Microsoft itself said, "YIPEE! Yourw new hawrdware suppowrts Bindows 11!!! YAY!" LIES! It'll fail during the installation phase. And if it didn't fail BEFORE you agree to install as a new drive or whatever. Boom. Wipes drive. All your loli hentai is eviscerated. Well in this case that's a good thing. Fucking disgusting).

So you're stuck between a piece of shit software and a piece of shit software with AI and you can't escape. Yipee.

## Am I a slave?

I will refrain from making a joke about slavery on African Americans during the 1800's, I do not want Twitter to come after me… yet…

But God forbid you use Adobe Creative Suite. Like why? It's 2025. Who pays for that shit? Even if you pirate it, it's still disgusting. It's like breaking into homes and stealing their rubbish. Why? Use free or open source alternatives.

- **Wanna edit videos?** Davinci Resolve. Your favourite film studios are using Da Twinki. Sure they have a Premium option. And also signing up for the free option is a little hassle. Like why do you need to know where I live? Bugger off. But it's free. And full support for Linux btw. Fire.

- **Wanna use photoshop?** A term that is now coined as a verb to alter digital image… GIMP! And I'm a simp for FOSS. You can even (idk you would want to) install an extension that turns all the shortcuts into Adobe's Photoshop shortcut. YAY! Old habits die hard. And so do I. wait…

And whatever else that fucker offers. Idk. There's probably an open source software for it.

This is just some examples of alternatives. But if you continue to use these services, that are proprietary to Windows software, you can't leave. It's a 'gotcha' if you ever wanna use Linux or whatever. "I can't use my Adobe apps". Honestly? It's for the best. Bite the bullet. It's made of candy. Pay the unsubscription fee, which by the way is scummy as fuck but I'm pretty sure it's illegal so something's gonna happen.

"But where do I go?" God you're so dumb.

## Linux: the penguin that never gets mad

Linux used to be super niche and using it leaves a sour taste in your mouth. You probably don't shower, only use CLI and still only chats in IRC. You probably wear a fedora in public.

But some random fucks all over the world that volunteered FOR FREE (Chads), to help develop Operating Systems that look and feel just like your comfort home that is rundown because you forget to pay rent, or probably pirated it anyways, Windows. Built on a kernel by some random Finnish guy in 1991 FOR FREE! He also publicly gave Nvidia the middle finger back in 2012 (Giga Chad). They made it so easy to use Linux for user that are not as tech savy. And even if you are, the terminal is right there. Big scary green boi. It gives you control over your machine. If you know what you're doing. If not, just read documents, ask questions in forums, fuck even use ChatGPT. It doesn't matter anymore. And the community is actively developing code that runs Windows based software on Linux. Even if it's not natively supported it will probably work on the Penguin OS.

Try Linux Mint for office use if you just wanna watch YouTube and do research on Japan cars from the late 90's, Ubuntu is the go-to for networking like in servers it's notoriously heavy but NOT bloated and VERY begineer friendly, Pop_OS! is seen as the gaming distro but there are gaming focused distros, like my favourite Steam OS, or go all in with Arch Linux. But I must warn you, it's only for you if you aren't afraid to fuck up 3 times just to succeed once. You ARE going to make mistakes. But that's the joy of it. So i recommend Linux Mint. But it almost really doesn't matter cuz if you didn't like, just get another one. It's just that easy.

## The Good Stuff

- **Privacy** Imagine your computer NOT selling your every personal info to Russia or China (or if you ARE russian or Chinese, not to America). What a dream… Or NOT. Cuz the penguin will almost never run background tracking apps that sees your every move like a hawk (tuah?). You could… idk why tho…

- **No Bloatware** Only have what you need. "But what if I don't I need?" Literally just go to your terminal and type `sudo apt install discord` and that's it. Literally. You will have to find out what package managers your OS uses. And also how you wanna install those files. Like Arch uses pacman, or yay. Basically, when installing apps, there's a special word you use right after `sudo`. Find which one you use and viola.

- **Full Control** I know `terminal` sounds like the things in the NERV HQ in Evangelion… because it is. It's basically how you interact with the Operating System from under the skirt. Computers were develop AROUND the terminal. Before fancy folder icons, we did everything in Command Line Interfaces where you interact in a single line of a text box. And it makes you look cool.

- **Free as in Beer AND Freedom** Did I mention it costs nothing? If it did, you fucked up. Because the OS that you will probably use for you desktop environment is most probably free. Just… kindly ask for a refund.

## Wait… Steam OS? Like the gaming marketplace

No steam like the smoke from trains. YES Steam from Valve. Valve correctly predicated that Microsoft would turn to subscription based and bloated intrusive approach to developing their software way before I was even fucking born (so like before yesterday). And quickly assigned their crew to make anything related to Valve support for Linux. Heavily. Using the corpse that is Wine to build Proton, a compatibility layer that allows Windows software to run on Linux-based operating systems. You can game on Linux, even if the game devs didn't intend to. Of course shit like Anti-cheat might have problems and that's a whole other bullshit. But you can play Elden Ring on Arch Linux. And that's the only game that you should ever play btw. Since Sony refuses to port Bloodbourne to PC.

Imagine if Valve released a product that is competitive in the handheld gaming market built around their own Operating System that supports almost any game to be playable almost anyway (for a limited time). OH WAIT THEY DID.

Le Steam Deck. Sounds like a boat that runs on water… or just a more advanced boat i guess… x86-64 based, same architecture as your desktop. Though devices like the Raspberry Pi use ARM which is far more suited for portable devices. Idk why laptops STILL do x86 64bit. YOU HAVE A BATTERY. You can watch LTT's video on YouTube reviewing the Steam Deck, and despite his critics, it still competes in the gaming market. I even considered purchasing one till i realized that instead of getting a job, I spend my hours writing a blog that nobody reads… hmm…

And if you're worried that your game isn't supported on Linux, ProtonDB is your friend. The DB stands for database, a database of games on Steam that supports Proton. If it isn't supported now, it will be in the close future (probably…)

## Cat and Mouse

We can't talk about gaming on Linux without mentioning Anti-cheat. Yes this means you can't play Valorant or FACEIT on Linux, which honestly, is for your own good. In a closed textbook, some anti-cheats run on kernel access. Windows' kernel access. Meant to stop bad guys from installing software that gives the player an unfair advantage when playing. Some even go to the hardware level like FACEIT's IOMMU checks which might actually brick your computer if it fails. MIGHT. Highly unlikely because those madlads know wtf their doing but it's STILL a failing point. But in case of Linux? Big no no. And it is too much effort for developers to provide support for Linux OS. That is because not enough of their playerbase or using Linux. Thus the solution is simple. More people on Linux, more supported, more happy. Steal the moon.

## The Future Is Open

Windows had a strong hand on the operating system industry. There was no asking what OS you use. It's always Microsoft's Windows, or you're a snob. And if you use Linux, you don't interact with other people. But not anymore. Linux continues to be widely adopted and support for Linux only continues to grow. No subscriptions, no inflation (pyrocynical ahh), no "Ah. Need an update. Sowwy." Take control of your device. It belongs to you. Even if you don't know how to use it. There's no Windows 10 for a blender. Why is a computer any different? It serves a purpose. Let it serve you. Don't become the product. Not anymore.

---

_Disclaimer: This blog post was written by a penguin._
